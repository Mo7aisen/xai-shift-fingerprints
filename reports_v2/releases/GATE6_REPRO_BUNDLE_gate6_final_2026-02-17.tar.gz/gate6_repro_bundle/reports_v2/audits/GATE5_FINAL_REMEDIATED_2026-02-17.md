# Gate-5 Final Decision

- Generated UTC: `2026-02-17T14:55:57.655756+00:00`
- Clinical gate: `PASS`
- Determinism gate: `PASS`
- Clinical score method: `topk_weighted_abs_z`
- Clinical score top-k: `5`

## Final Status

- Gate-5 final: `PASS`
- Clinical summary: `/storage/xai_cxr_safety/xai_shift_fingerprints_reproduction_20251225_full/reports_v2/audits/GATE5_CLINICAL_SUMMARY_REMEDIATED.json`
- Determinism summary: `/storage/xai_cxr_safety/xai_shift_fingerprints_reproduction_20251225_full/reports_v2/audits/GATE5_BITWISE_DETERMINISM_SUMMARY.json`
- JSON output: `/storage/xai_cxr_safety/xai_shift_fingerprints_reproduction_20251225_full/reports_v2/audits/GATE5_FINAL_SUMMARY_REMEDIATED.json`
