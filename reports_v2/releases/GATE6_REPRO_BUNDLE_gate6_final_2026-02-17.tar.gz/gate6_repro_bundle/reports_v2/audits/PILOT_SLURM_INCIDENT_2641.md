# Slurm Pilot Incident Report

Date: 2026-02-17T11:33:26Z
Job ID: 2641
Run ID: slurm_pilot_seed42_jsrt_full_2641
Status: FAILED
Exit code: 2

## Context
- Experiment: jsrt_to_montgomery
- Subset: full
- Seed: 42
- Endpoints: predicted_mask+mask_free
- Time limit: 00:30:00

## Note
Unhandled error

## Timing
- Start: 2026-02-17T11:33:25Z
- End: 2026-02-17T11:33:26Z
