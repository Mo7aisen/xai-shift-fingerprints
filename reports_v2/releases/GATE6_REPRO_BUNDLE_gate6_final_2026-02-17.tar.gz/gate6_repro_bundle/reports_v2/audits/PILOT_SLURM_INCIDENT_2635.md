# Slurm Pilot Incident Report

Date: 2026-02-17T11:18:40Z
Job ID: 2635
Run ID: slurm_pilot_seed42_jsrt_pilot5_2635
Status: FAILED
Exit code: 1

## Context
- Experiment: jsrt_baseline
- Subset: pilot5
- Seed: 42
- Endpoints: predicted_mask+mask_free
- Time limit: 00:30:00

## Note
Unhandled error

## Timing
- Start: 2026-02-17T11:18:09Z
- End: 2026-02-17T11:18:40Z
