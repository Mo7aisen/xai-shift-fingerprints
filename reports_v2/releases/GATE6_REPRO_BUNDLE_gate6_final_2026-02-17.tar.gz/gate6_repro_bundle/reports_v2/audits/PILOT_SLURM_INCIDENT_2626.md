# Slurm Pilot Incident Report

Date: 2026-02-17T11:05:55Z
Job ID: 2626
Run ID: slurm_pilot_seed42_jsrt_pilot5_2626
Status: FAILED
Exit code: 127

## Context
- Experiment: jsrt_baseline
- Subset: pilot5
- Seed: 42
- Endpoints: predicted_mask+mask_free
- Time limit: 00:30:00

## Note
Unhandled error

## Timing
- Start: 2026-02-17T11:05:55Z
- End: 2026-02-17T11:05:55Z
