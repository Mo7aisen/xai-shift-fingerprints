# Slurm Pilot Incident Report

Date: 2026-02-17T11:07:11Z
Job ID: 2628
Run ID: slurm_pilot_seed42_jsrt_pilot5_2628
Status: FAILED
Exit code: 1

## Context
- Experiment: jsrt_baseline
- Subset: pilot5
- Seed: 42
- Endpoints: predicted_mask+mask_free
- Time limit: 00:30:00

## Note
Unhandled error

## Timing
- Start: 2026-02-17T11:06:43Z
- End: 2026-02-17T11:07:11Z
