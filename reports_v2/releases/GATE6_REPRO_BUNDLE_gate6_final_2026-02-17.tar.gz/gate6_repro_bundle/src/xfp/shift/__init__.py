"""Dataset shift scoring utilities."""
