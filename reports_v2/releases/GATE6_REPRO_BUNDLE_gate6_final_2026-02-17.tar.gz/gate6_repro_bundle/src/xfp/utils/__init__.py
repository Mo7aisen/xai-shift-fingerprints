"""Miscellaneous helpers."""
