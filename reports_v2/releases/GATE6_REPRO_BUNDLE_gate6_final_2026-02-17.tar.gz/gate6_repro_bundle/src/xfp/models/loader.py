"""Utilities for loading pretrained segmentation models.

This module provides checkpoint loading for UNet segmentation models.
For reproducibility, legacy model paths are configured via environment variable.
"""

from __future__ import annotations

import importlib
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Optional, Sequence, Tuple, Type

import torch

# Environment variable for configuring legacy model sources
# Set XFP_LEGACY_MODEL_PATHS to a colon-separated list of paths
# Example: export XFP_LEGACY_MODEL_PATHS="/path/to/scba/src:/path/to/other/src"
_ENV_LEGACY_PATHS = "XFP_LEGACY_MODEL_PATHS"

# Default paths (used only if env var not set and paths exist)
_DEFAULT_LEGACY_SOURCES = (
    "~/xaiproject/src",
    "~/xai/src",
    "~/SCBA",
    "~/UARF-AQA_code_only",
    "~/phd_segmentation_xai_app/active_learning/src",
)


def _get_legacy_model_sources() -> Sequence[Path]:
    """Get legacy model source paths from environment or defaults.

    Priority:
    1. XFP_LEGACY_MODEL_PATHS environment variable (colon-separated)
    2. Default paths expanded from home directory

    Returns:
        Sequence of valid, existing paths for legacy model imports.
    """
    env_paths = os.environ.get(_ENV_LEGACY_PATHS)

    if env_paths:
        # Use environment-configured paths
        candidates = [Path(p.strip()).expanduser() for p in env_paths.split(":") if p.strip()]
    else:
        # Fall back to defaults (expanded from ~)
        candidates = [Path(p).expanduser() for p in _DEFAULT_LEGACY_SOURCES]

    # Filter to only existing paths
    valid_paths = [p for p in candidates if p.exists()]

    if not valid_paths and not env_paths:
        warnings.warn(
            f"No legacy model source paths found. Set {_ENV_LEGACY_PATHS} environment variable "
            "to a colon-separated list of paths containing UNet model definitions. "
            "Example: export XFP_LEGACY_MODEL_PATHS='/path/to/scba/src:/path/to/models'",
            UserWarning,
            stacklevel=2,
        )

    return valid_paths


def _ensure_legacy_imports() -> None:
    """Add legacy model source directories to sys.path for import resolution."""
    for path in reversed(_get_legacy_model_sources()):
        path_str = str(path)
        if path_str not in sys.path:
            sys.path.insert(0, path_str)


def load_unet_checkpoint(checkpoint_path: Path, device: str = "cuda") -> torch.nn.Module:
    """Load a UNet checkpoint using the legacy model definition."""

    _ensure_legacy_imports()
    unet_cls = _resolve_unet_class()
    checkpoint = _load_checkpoint(checkpoint_path, device=device)
    model_kwargs = _extract_model_kwargs(checkpoint)

    # Keep legacy-safe fallback order for checkpoints that do not record model_config.
    constructor_attempts = [
        model_kwargs,
        {},
        {"n_channels": 1, "n_classes": 1},
    ]
    model = None
    for kwargs in constructor_attempts:
        try:
            model = unet_cls(**kwargs)
            break
        except TypeError:
            continue
    if model is None:
        raise TypeError(f"Unable to instantiate UNet class {unet_cls} for checkpoint {checkpoint_path}")

    state_dict = _extract_state_dict(checkpoint, checkpoint_path)
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()
    return model


def _load_checkpoint(checkpoint_path: Path, device: str) -> Any:
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    # Always load to CPU first; move the model to the target device afterwards.
    # This avoids CUDA driver issues during deserialization on some vGPU setups.
    return torch.load(checkpoint_path, map_location="cpu")


def _extract_state_dict(checkpoint: Any, checkpoint_path: Path) -> dict:
    if isinstance(checkpoint, dict):
        for key in ("state_dict", "model_state_dict"):
            if key in checkpoint and isinstance(checkpoint[key], dict):
                return checkpoint[key]
        # Raw state dict serialization.
        if checkpoint and all(isinstance(k, str) for k in checkpoint.keys()):
            return checkpoint
    raise ValueError(f"Unrecognized checkpoint format in {checkpoint_path}")


def _extract_model_kwargs(checkpoint: Any) -> dict[str, Any]:
    if not isinstance(checkpoint, dict):
        return {}
    cfg = checkpoint.get("model_config")
    if not isinstance(cfg, dict):
        return {}
    kwargs: dict[str, Any] = {}
    for key in ("n_channels", "n_classes", "features"):
        if key in cfg:
            kwargs[key] = cfg[key]
    if isinstance(kwargs.get("features"), list):
        kwargs["features"] = tuple(int(x) for x in kwargs["features"])
    return kwargs


def _resolve_unet_class() -> Type[torch.nn.Module]:
    """Import the UNet definition from the most reliable legacy source."""

    module_candidates = (
        "scba.models.unet",  # matches the checkpoints we retrained post-fix
        "xfp.models.unet",  # local fallback implementation
        "models.unet",
        "models.model",
    )

    last_error: Optional[ImportError] = None
    for module_name in module_candidates:
        try:
            module = importlib.import_module(module_name)
        except ImportError as exc:
            last_error = exc
            continue
        unet_cls = getattr(module, "UNet", None)
        if unet_cls is not None:
            return unet_cls  # type: ignore[return-value]

    raise ImportError(
        "Unable to locate a UNet implementation in the expected legacy repositories. "
        "Checked modules: "
        + ", ".join(module_candidates)
    ) from last_error
