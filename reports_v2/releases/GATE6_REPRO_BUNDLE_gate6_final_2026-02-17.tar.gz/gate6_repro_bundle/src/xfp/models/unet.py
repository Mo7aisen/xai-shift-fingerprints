"""Minimal UNet implementation used for training and inference."""

from __future__ import annotations

import torch
from torch import nn


class DoubleConv(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class UNet(nn.Module):
    """UNet for single-channel medical image segmentation."""

    def __init__(
        self,
        n_channels: int = 1,
        n_classes: int = 1,
        features: tuple[int, int, int, int] = (32, 64, 128, 256),
    ) -> None:
        super().__init__()
        self.downs = nn.ModuleList()
        self.ups = nn.ModuleList()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        in_ch = n_channels
        for feat in features:
            self.downs.append(DoubleConv(in_ch, feat))
            in_ch = feat

        self.bottleneck = DoubleConv(features[-1], features[-1] * 2)

        rev_features = list(reversed(features))
        up_in = features[-1] * 2
        for feat in rev_features:
            self.ups.append(nn.ConvTranspose2d(up_in, feat, kernel_size=2, stride=2))
            self.ups.append(DoubleConv(up_in, feat))
            up_in = feat

        self.final_conv = nn.Conv2d(features[0], n_classes, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skip_connections = []
        for down in self.downs:
            x = down(x)
            skip_connections.append(x)
            x = self.pool(x)

        x = self.bottleneck(x)
        skip_connections = list(reversed(skip_connections))

        for idx in range(0, len(self.ups), 2):
            x = self.ups[idx](x)
            skip = skip_connections[idx // 2]
            if x.shape != skip.shape:
                x = nn.functional.interpolate(x, size=skip.shape[2:], mode="bilinear", align_corners=False)
            x = torch.cat([skip, x], dim=1)
            x = self.ups[idx + 1](x)

        return self.final_conv(x)
