# Tests package init.
